# config.py
import os
class Config:
    DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@db/ben_bot_db")
    SECRET_KEY = os.getenv("SECRET_KEY", "a_random_secret_key")
    ALGORITHM = "HS256"