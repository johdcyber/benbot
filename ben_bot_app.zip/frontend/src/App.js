// App.js
import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to Ben Bot Frontend</h1>
    </div>
  );
}

export default App;